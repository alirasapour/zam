var fins = require('omron-fins');
var client = fins.FinsClient(9600, '169.254.68.112');
const axios = require('axios').default;
client.on('error', function (error) {
	console.log("Error: ", error);
});

client.on('reply', function (msg) {
	console.log("Reply from: ", msg.remotehost);
	console.log("Transaction SID: ", msg.sid)
	console.log("Replying to issued command of: ", msg.command);
	console.log("Response code of: ", msg.code);
	console.log("Data returned: ", msg.values);
});

// D2112 cunter tolid
// D1000 speed B/H
// D2172 Motor DC Speed



setInterval(() => {
	client.read('D2112', 1, function (err, bytes) {
		console.log("Bytes: ", bytes);
		// Make a request for a user with a given ID
		axios.get(`http://localhost:3000/14000data/setFromPLC?Tolid=${bytes}`)
			.then(function (response) {
				// handle success
				console.log(response);
			})
			.catch(function (error) {
				// handle error
				console.log(error);
			})
			.then(function () {
				// always executed
			});

	});
}, 900);

// setInterval(() => {
// 	console.clear();
// 	client.readMultiple('D2112','D1000','D2172','CB100:00','D2108','D1162','D1160','D2172','D1190');
// }, 1500);
