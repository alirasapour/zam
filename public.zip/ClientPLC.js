var fins = require('omron-fins');
var client = fins.FinsClient(9600, '169.254.68.112');
client.on('error', function (error) {
	console.log("Error: ", error);
});
const axios = require('axios').default;
console.clear();
process.title = "ZamZam Client Contorller Application";

client.on('reply', function (msg) {
	axios.get(`http://62.3.41.238:3000/14000data/setFromPLC?Tolid=${msg.values[0]}&Speed=${msg.values[1]}`)
		.then(function (response) {
		})
		.catch(function (error) {
			console.log(error);
		})
	console.log(msg.values[0]);
});

// D2112 cunter tolid // D1000 speed B/H // D2172 Motor DC Speed
setInterval(() => {
	client.readMultiple('D2112', 'D1000');
}, 350);


setInterval(() => {
	axios.get(`http://62.3.41.238:3000/14000data/getPLCFunction`)
		.then(function (response) {
			if(response.data == 1){
				client.run()
			}else if(response.data == 0){
				client.stop()
			}
		})
		.catch(function (error) {
			console.log(error);
		})
}, 500);

// 62.3.41.238
// g2dtYthhwT04dX