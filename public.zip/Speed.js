var fins = require('omron-fins');
var client = fins.FinsClient(9600, '169.254.68.112');
let Speed = 10000
const axios = require('axios').default;
console.clear();
process.title = "ZamZam Speed Client Contorller App";
axios.get(`http://localhost:3000/14000data/getSpeedLine`)
			.then(function (response) {
				setTimeout(() => {
					console.log(typeof(response.data.Speed))
					// client.write('D1000',response.data.Speed)
				}, 200);
			})
			.catch(function (error) {
				console.log(error);
			})
client.on('error', function (error) {
	console.log("Error: ", error);
});




client.on('reply', function (msg) {
	// console.log(msg.values[0]);
});

// D2112 cunter tolid // D1000 speed B/H // D2172 Motor DC Speed
setInterval(() => {
	client.readMultiple('D2112');
}, 420);

// Line Speed
setInterval(() => {
		axios.get(`http://localhost:3000/14000data/getSpeedLine`)
			.then(function (response) {
				console.log(response.data.Speed);
				setTimeout(() => {
					client.write('D1000',response.data.Speed)
				}, 200);
			})
			.catch(function (error) {
				console.log(error);
			})
}, 900);


