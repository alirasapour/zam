console.clear();
const express = require('express');
const app = express()
const port = 3000
const open = require('open');
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
let line1400 = {
	Status: 'نامشخص',
	Tolid: 0,
	Speed: 10000,
	Status : 1,
	FunctionRS : 2
}

// setTimeout(async () => {
// 	await open('http://localhost:3000', { app: { name: 'firefox' } });
// }, 2000);

app.get('/', (req, res) => {
	res.render('./dashboard.ejs')
})


app.get('/14000data', (req, res) => {
	res.json(line1400)
})

app.get('/14000data/getPLCFunction', (req, res) => {
	let func = line1400.FunctionRS;
	line1400.FunctionRS = 2
	res.json(func)
})

app.get('/14000data/setSpeed', (req, res) => {
	// line1400.Speed = req.query.Speed
	res.send('1')
})

app.get('/14000data/getSpeedLine', (req, res) => {
	res.json(line1400)
})

app.get('/14000data/setFromPLC', (req, res) => {
	line1400.Tolid = req.query.Tolid
	line1400.Speed = req.query.Speed
	res.send('1')
})

// PLC OmRon -> STOP
app.get('/stop', (req, res) => {
	line1400.Status = 0,
	line1400.FunctionRS = 0
	res.json(1)
})
// PLC OmRon -> RUN
app.get('/run', (req, res) => {
	line1400.Status = 1,
	line1400.FunctionRS = 1
	res.json(1)
})
// View Route
app.get('/14000', (req, res) => {
	res.render('./14000Line.ejs')
})

app.get('/home', (req, res) => {
	res.render('./index.ejs')
})


app.listen(port, () => {
	console.log(`ZamZam webApplication listening on port ${port}`)
})
